const config = {
  apiUrl: '/api_akiha_kadohama'
};

export default config;