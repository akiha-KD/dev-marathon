const config = {
  apiUrl: 'http://localhost:5238'
};

export default config;